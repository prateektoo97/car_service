package com.car_repair_shop.car_repair.web.admin_controllers.vehicle;

import com.car_repair_shop.car_repair.converters.VehicleConverter;
import com.car_repair_shop.car_repair.domain.Member;
import com.car_repair_shop.car_repair.domain.Vehicle;
import com.car_repair_shop.car_repair.forms.vehicle.ServiceForm;
import com.car_repair_shop.car_repair.forms.vehicle.VehicleForm;
import com.car_repair_shop.car_repair.services.member.MemberService;
import com.car_repair_shop.car_repair.services.vehicle.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

import static com.car_repair_shop.car_repair.properties.Constants.ERROR_MESSAGE;

@Controller
public class VehicleCreateController {

    private static final String VEHICLE_FORM = "serviceForm";

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private MemberService memberService;


    @RequestMapping(value = "member/create-vehicle", method = RequestMethod.GET)
    public String getCreateVehicleView(@RequestParam(required=false) String id,@RequestParam(required=false) String mobile,@RequestParam(required=false) String email,Model model, RedirectAttributes redirectAttributes) {

        if (!model.containsAttribute(VEHICLE_FORM)) {
        	ServiceForm serviceForm=new ServiceForm();
        	serviceForm.setName(id);
        	serviceForm.setMobile(mobile);
        	serviceForm.setVat(mobile);
        	serviceForm.setCustName(email);
            model.addAttribute(VEHICLE_FORM, serviceForm);
        }
        
        return "/admin/vehicle/create-vehicle-view";
    }
    
    @RequestMapping(value = "member/create-service", method = RequestMethod.POST)
    public String getCreateServiceView(@Valid @ModelAttribute(name = VEHICLE_FORM) ServiceForm serviceForm,
            BindingResult bindingResult, RedirectAttributes redirectAttributes) {

        return "/admin/vehicle/create-vehicle-view";
    }

    @RequestMapping(value = "/member/create-vehicle", method = RequestMethod.POST)
    public String createVehicle(@Valid @ModelAttribute(name = VEHICLE_FORM) ServiceForm vehicleForm,
                             BindingResult bindingResult, RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.vehicleForm", bindingResult);
            redirectAttributes.addFlashAttribute(VEHICLE_FORM, vehicleForm);

            return "redirect:/admin/create-vehicle";
        }

        String memberVat = vehicleForm.getVat();
        String memberName=vehicleForm.getName();
        Vehicle vehicle;

        try {
            vehicle = VehicleConverter.buildVehicleObjecr(vehicleForm);
            Member member = memberService.getMemberByEmail(vehicleForm.getCustName());
            //Member member = memberService.getMemberByVat(memberVat);
            vehicle.setMember(member);
            vehicle = vehicleService.insertVehicle(vehicle);

        } catch (Exception e) {
            String message = "There is not user with Mobile: " + memberVat + " or vehicle already exists";

            redirectAttributes.addFlashAttribute(ERROR_MESSAGE, message);
            redirectAttributes.addFlashAttribute(VEHICLE_FORM, vehicleForm);

            return "redirect:/member/create-vehicle";
        }

        String message = "Your vehicle with plate: " + vehicle.getPlate().toUpperCase() +
                         " is booked for user with mechanic: " + memberName;

        redirectAttributes.addFlashAttribute("message", message);

        return "redirect:/member/create-vehicle";
    }

}
