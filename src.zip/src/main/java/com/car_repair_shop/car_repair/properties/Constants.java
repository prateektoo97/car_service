package com.car_repair_shop.car_repair.properties;

public class Constants {

    public static final String ERROR_MESSAGE = "errorMessage";
    public static final String MEMBER = "MEMBER";
    public static final String ADMIN = "ADMIN";
    public static final String TRUE = "true";
}
