package com.car_repair_shop.car_repair.exceptions;

public class RepairNotFoundException extends Exception{

    public RepairNotFoundException(String msg) { super(msg); }
}
