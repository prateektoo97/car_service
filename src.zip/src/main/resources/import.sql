insert into user (user_id,email,password,user_type) values(1,"ioannis@ioannou.gr","$2a$10$/1vpOmGiECBAdjklH8sfYexhlxWWrp5KA.wA9E4K2YjVf8ZI5asqe",false);
insert into user (user_id,email,password,user_type) values(2,"georgios@georgiou.gr","$2a$10$/1vpOmGiECBAdjklH8sfYexhlxWWrp5KA.wA9E4K2YjVf8ZI5asqe",false);
insert into user (user_id,email,password,user_type) values(3,"akis@akis.gr","$2a$10$/1vpOmGiECBAdjklH8sfYexhlxWWrp5KA.wA9E4K2YjVf8ZI5asqe",true);
insert into user (user_id,email,password,user_type) values(4,"tsapas@gmail.gr","$2a$10$/1vpOmGiECBAdjklH8sfYexhlxWWrp5KA.wA9E4K2YjVf8ZI5asqe",true);

insert into member (idmember,address,firstname,lastname,vat,user_id)  values(1,'Karpenisiou 3','loannis','Ioannou','123234345',1);
insert into member (idmember,address,firstname,lastname,vat,user_id)  values(2,'Kavalas 12','Georgios','Georgiou','123345789',2);
insert into member (idmember,address,firstname,lastname,vat,user_id)  values(3,'Athinas 8','Akis','Dimopoulos','456852397',3);
insert into member (idmember,address,firstname,lastname,vat,user_id)  values(4,'Kabalas 10','Kostas','Poulakakis','222312312',4);

INSERT INTO vehicle (vehicle_id, brand, color, model, plate, year, user_id) VALUES (1, 'BMW', 'Red', 'Model1', 'ABC-1234', '2017-01-01', 1);
INSERT INTO vehicle (vehicle_id, brand, color, model, plate, year, user_id) VALUES (2, 'Toyota', 'Blue', 'Model1', 'KEF-1234', '2012-01-01', 2);
INSERT INTO vehicle (vehicle_id, brand, color, model, plate, year, user_id) VALUES (3, 'Nissan', 'Black', 'Model1', 'BHI-1234', '1999-01-01', 3);
INSERT INTO vehicle (vehicle_id, brand, color, model, plate, year, user_id) VALUES (4, 'Scoda', 'White', 'Model1', 'AKL-1234', '2000-01-01', 4);
INSERT INTO vehicle (vehicle_id, brand, color, model, plate, year, user_id) VALUES (5, 'BMW', 'Red', 'Model1', 'ABC-4321', '2002-01-01', 4);
INSERT INTO vehicle (vehicle_id, brand, color, model, plate, year, user_id) VALUES (6, 'Toyota', 'Blue', 'Model1', 'HHH-4321', '2014-01-01', 3);
INSERT INTO vehicle (vehicle_id, brand, color, model, plate, year, user_id) VALUES (7, 'Nissan', 'Black', 'Model1', 'XHI-4321', '2014-01-01', 2);
INSERT INTO vehicle (vehicle_id, brand, color, model, plate, year, user_id) VALUES (8, 'Scoda', 'White', 'Model1', 'OPI-4321', '2014-01-01', 1);

insert into repair (repair_id,repair_date, cost, description, status, type, vehicle_id) VALUES (1,'2017-10-27 11:00:00','100', 'This is a description1', '0', false,1);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (2,'2017-10-27 12:00:00','100', 'This is a description2', '1',  true,2);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (3,'2017-10-27 13:00:00','100', 'This is a description3', '2',  false,3);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (4,'2017-10-27 10:00:00','100', 'This is a description4', '0',  true,4);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (5,'2017-10-27 09:00:00','100', 'This is a description1', '0', false,1);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (6,'2017-10-27 08:00:00','100', 'This is a description2', '1',  true,2);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (7,'2017-10-27 07:00:00','100', 'This is a description3', '2',  false,3);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (8,'2017-10-27 15:30:00','100', 'This is a description4', '0',  true,4);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (9,'2017-10-27 15:45:00','100', 'This is a description1', '0', false,1);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (10,'2017-10-27 15:15:00','100', 'This is a description2', '1',  true,2);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (11,'2017-10-27 20:15:00','100', 'This is a description3', '2',  false,3);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (12,'2017-10-27 19:30:00','100', 'This is a description4', '0',  true,4);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (13,'2017-10-27 14:45:00','100', 'This is a description1', '0', false,1);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (14,'2017-10-24 15:00:00','100', 'This is a description2', '1',  true,2);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (15,'2017-10-25 15:00:00','100', 'This is a description3', '2',  false,3);
insert into repair (repair_id, repair_date, cost, description, status, type, vehicle_id) VALUES (16,'2017-10-26 15:00:00','100', 'This is a description4', '0',  true,4);





